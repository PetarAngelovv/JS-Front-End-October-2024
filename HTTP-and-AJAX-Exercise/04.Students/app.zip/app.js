function attachEvents() {
  const baseUrl = 'http://localhost:3030/jsonstore/collections/students';
  const output = document.querySelector('tbody');

  function loadStudents(){

  fetch(baseUrl)
      .then(response => response.json())
      .then(data => {
          Object.values(data).forEach(AddStudentToTable);
      })
      .catch(error => console.error('Error: ', error));
  }

  function AddStudentToTable({firstName,lastName,facultyNumber,grade}){
            const tr = document.createElement('tr');
             tr.innerHTML =`
             <td>${firstName}</td>
             <td>${lastName}</td>
             <td>${facultyNumber}</td>
             <td>${grade}</td>
             `
              output.append(tr);
  }

  function createStudent(e){
    const results = [...output.querySelectorAll('input[name]')];
    const [firstName,lastName,facultyNumber,grade] = results.map(element => element.value);

    if( ! firstName || ! lastName || ! facultyNumber || ! grade ) return
  
    const body = {firstName,lastName,facultyNumber,grade}
    
     fetch(baseUrl,{
         method:'POST',
         headers: { 'Content-Type': 'application/json' },
         body: JSON.stringify(body)
     })
     .then(response => response.json())
     .then( newStudent => {
       AddStudentToTable(newStudent);
       inputs.forEach(el => el.value = '')
      })
      .catch(error => console.error('Error: ',error))
  };

  document.querySelector('#submit').addEventListener('click', createStudent)
  loadStudents();
}
attachEvents();